INSERT INTO public.produto(descricao, preco_unitario) VALUES ('Arroz Tio Joao','5.40');
INSERT INTO public.produto(descricao, preco_unitario) VALUES ('Macarrão','8.00');
INSERT INTO public.produto(descricao, preco_unitario) VALUES ('Batata','2.00');
INSERT INTO public.produto(descricao, preco_unitario) VALUES ('Erva Doce','10.45');
INSERT INTO public.produto(descricao, preco_unitario) VALUES ('Açúcar','8.00');
INSERT INTO public.produto(descricao, preco_unitario) VALUES ('Laranja Doce','20.30');


INSERT INTO public.usuario(data_atualizacao,data_cadastro,login, nome, senha) VALUES (timezone('utc', CURRENT_TIMESTAMP(0)),timezone('utc', CURRENT_TIMESTAMP(0)), 'marinalarissa', 'Marina Larissa', '102030');
INSERT INTO public.usuario(data_atualizacao,data_cadastro,login, nome, senha) VALUES (timezone('utc', CURRENT_TIMESTAMP(0)),timezone('utc', CURRENT_TIMESTAMP(0)), 'larissarohrig', 'Larissa Marina', '302010');
INSERT INTO public.usuario(data_atualizacao,data_cadastro,login, nome, senha) VALUES (timezone('utc', CURRENT_TIMESTAMP(0)),timezone('utc', CURRENT_TIMESTAMP(0)), 'Tutu', 'Testezinho', '10000');
INSERT INTO public.usuario(data_atualizacao,data_cadastro,login, nome, senha) VALUES (timezone('utc', CURRENT_TIMESTAMP(0)),timezone('utc', CURRENT_TIMESTAMP(0)), 'Lalala', 'Lalalala', '235523');
INSERT INTO public.usuario(data_atualizacao,data_cadastro,login, nome, senha) VALUES (timezone('utc', CURRENT_TIMESTAMP(0)),timezone('utc', CURRENT_TIMESTAMP(0)), 'Luluzinha', 'Luciana', '15523');

INSERT INTO public.telefone(numero, tipo, id_usuario) VALUES ('999999999','Celular',1);
INSERT INTO public.telefone(numero, tipo, id_usuario) VALUES ('23456234223','Casa',1);

